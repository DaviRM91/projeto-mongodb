package com.davi.workshopmongo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkshopmongoApplicationTests {

	@Test
	void contextLoads() {
	}

}
